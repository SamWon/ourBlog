<?php

return array(
    'defaultController' => 'home',
    
    //databaseConfiguration 
    'hostname' => '127.0.0.1',
    'username' => 'root',
    'password' => 'fuckyou',
    'database' => 'ourblog',

    //pagination 
    'pagination' => 2
);
